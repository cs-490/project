# chatroom-php-mysql

Follow this:
https://www.youtube.com/watch?v=rZ3EZuQecUM&list=PLCakfctNSHkErzd6KgnMrm6nY7hg5TUAm
