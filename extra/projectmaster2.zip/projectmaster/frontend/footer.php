<?php include('message.php') ;?>
    <!-- JavaScript -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js

"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.min.js"></script>
    <script src="./js/ckeditor/ckeditor.js"></script>
    <script src="js/main.js"></script>